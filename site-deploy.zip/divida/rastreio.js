/*
 * Rastreamento do funil Dívida Clara (quiz e VSL).
 * - Cria uma sessão anônima que acompanha a pessoa do quiz até a compra.
 * - Guarda as UTMs do anúncio.
 * - Mostra o aviso de cookies (modelo de oposição): o pixel do Meta liga por padrão,
 *   com base no legítimo interesse, e desliga para quem tocar em "Não quero".
 * - Cada evento vai para o pixel e para o seu servidor (api/track.php) com o
 *   MESMO ID, para a Meta descartar o duplicado.
 * Configure em cada página: window.RASTREIO_CONFIG = { page, pixelId, trackUrl }
 */
(function () {
  var R = window.RASTREIO_CONFIG || {};
  var UTM_KEYS = ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"];
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  function rid() {
    var a = new Uint8Array(12);
    (window.crypto || window.msCrypto).getRandomValues(a);
    return Array.prototype.map.call(a, function (b) { return ("0" + b.toString(16)).slice(-2); }).join("");
  }
  function cookie(name) { var m = document.cookie.match(new RegExp("(?:^|; )" + name + "=([^;]*)")); return m ? decodeURIComponent(m[1]) : null; }

  /* Sessão anônima */
  var sid = store("dc_sid");
  if (!sid) { sid = "s" + rid(); store("dc_sid", sid); }

  /* UTMs: as da URL atual têm prioridade; senão, as guardadas da visita anterior */
  var params = new URLSearchParams(location.search), utm = {};
  var saved = {}; try { saved = JSON.parse(store("dc_utm") || "{}"); } catch (e) {}
  var hasNew = UTM_KEYS.some(function (k) { return params.get(k); });
  UTM_KEYS.forEach(function (k) { var v = hasNew ? params.get(k) : saved[k]; if (v) utm[k] = v; });
  if (hasNew) store("dc_utm", JSON.stringify(utm));

  /* fbclid → cookie _fbc (melhora a correspondência na Meta).
     O fbclid fica guardado para as páginas seguintes (quiz → VSL) e para quem volta depois. */
  var host = location.hostname.replace(/^www\./, ""), dom = /dividaclara\.com\.br$/.test(host) ? "; domain=." + host : "";
  function setCookie(n, v) { document.cookie = n + "=" + v + "; path=/; max-age=7776000; SameSite=Lax" + dom; }
  var fbclid = params.get("fbclid");
  if (fbclid) store("dc_fbclid", JSON.stringify({ v: fbclid, t: Date.now() }));
  else { try { var f = JSON.parse(store("dc_fbclid") || "null"); if (f && Date.now() - f.t < 7776000000) fbclid = f.v; } catch (e) {} }
  if (fbclid && (!cookie("_fbc") || cookie("_fbc").split(".").pop() !== fbclid)) setCookie("_fbc", "fb.1." + Date.now() + "." + fbclid);

  /* Consentimento e pixel */
  var consent = store("dc_consent") !== "no", pixelOn = false, pageViewId = "pv_" + rid();
  if (consent && !cookie("_fbp")) setCookie("_fbp", "fb.1." + Date.now() + "." + Math.floor(Math.random() * 1e10));
  function loadPixel() {
    if (!R.pixelId || pixelOn) return; pixelOn = true;
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
    fbq("init", R.pixelId);
    fbq("track", "PageView", {}, { eventID: pageViewId });
  }

  /* Envia para o servidor */
  function send(body) {
    if (!R.trackUrl) return;
    var json = JSON.stringify(body);
    try {
      if (navigator.sendBeacon && navigator.sendBeacon(R.trackUrl, new Blob([json], { type: "text/plain" }))) return;
    } catch (e) {}
    try { fetch(R.trackUrl, { method: "POST", body: json, keepalive: true, headers: { "Content-Type": "text/plain" } }); } catch (e) {}
  }

  /*
   * dcTrack("Lead", { custom, data, step, level, value, lead, id, perfil, quiz })
   * custom: true para eventos personalizados (QuizStart, QuizStep, QuizComplete, QuizSkipLead, VideoProgress)
   * perfil: "a" | "b" | "c" (resultado do quiz). Fica guardado e vai junto em todos os eventos seguintes.
   * quiz: respostas do quiz { tipo_divida, tempo_atraso, cobrador, historico, sobra_mes }
   */
  function dcTrack(ev, o) {
    o = o || {};
    var id = o.id || (ev.toLowerCase() + "_" + rid());
    if (pixelOn && window.fbq && ev !== "PageView") {
      var data = o.data || {};
      if (o.custom) fbq("trackCustom", ev, data, { eventID: id }); else fbq("track", ev, data, { eventID: id });
    }
    var p = o.perfil || params.get("p") || store("dc_perfil");
    if (p && /^[abc]$/.test(p)) store("dc_perfil", p); else p = undefined;
    send({
      ev: ev, id: id, sid: sid, page: R.page, url: location.href.split("#")[0],
      consent: consent, utm: utm, step: o.step, level: o.level, value: o.value, lead: o.lead,
      perfil: p, quiz: o.quiz, ab: store("dc_ab") || undefined,
      fbp: cookie("_fbp"), fbc: cookie("_fbc"), fbclid: fbclid || undefined
    });
    return id;
  }

  window.dcTrack = dcTrack;
  window.dcSession = function () { return sid; };
  window.dcUtm = function () { return utm; };

  /* Aviso de cookies (elemento #consent da página): informa e permite recusar */
  function initBanner() {
    var banner = document.getElementById("consent");
    var choice = store("dc_consent");
    if (choice !== "no") loadPixel();
    if (!choice && R.pixelId && banner) banner.classList.add("show");
    if (banner) banner.addEventListener("click", function (e) {
      var b = e.target.closest("[data-consent]"); if (!b) return;
      store("dc_consent", b.dataset.consent); banner.classList.remove("show");
      if (b.dataset.consent === "no") {
        consent = false;
        try { if (window.fbq) fbq("consent", "revoke"); } catch (err) {}
      }
    });
    // PageView no servidor com o mesmo ID do pixel
    dcTrack("PageView", { id: pageViewId });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initBanner); else initBanner();

  /* Diagnóstico (só no seu banco, nada vai para a Meta): tempo de carga, se a pessoa
     tocou/rolou, se ficou 10 s, quanto tempo ficou, em que tela saiu e erros de JavaScript */
  function diag(ev, o) { o = o || {}; send({ ev: ev, id: ev.toLowerCase() + "_" + rid(), sid: sid, page: R.page, url: location.href.split("#")[0], consent: consent, utm: utm, step: o.step, value: o.value, erro: o.erro, ab: store("dc_ab") || undefined }); }
  var t0 = Date.now(), errs = 0, engaged = false;
  function tela() { var a = document.querySelector(".screen.active"); return a && a.id ? String(a.id).slice(0, 20) : "pagina"; }
  window.addEventListener("error", function (e) {
    if (errs++ >= 3) return;
    diag("JsError", { erro: String((e && e.message) || "erro") + " @" + String((e && e.filename) || "").split("/").pop() + ":" + ((e && e.lineno) || 0) });
  });
  function onEngage(e) {
    if (engaged) return; engaged = true;
    diag("Engaged", { step: e.type === "scroll" ? "rolou" : "tocou", value: Math.round((Date.now() - t0) / 100) / 10 });
  }
  ["touchstart", "scroll", "mousedown", "keydown"].forEach(function (t) { window.addEventListener(t, onEngage, { passive: true, once: true }); });
  setTimeout(function () { if (!document.hidden) diag("Engaged", { step: "10s" }); }, 10000);
  function carga() { try { var n = performance.getEntriesByType("navigation")[0]; diag("Carga", { value: Math.round((n ? n.domContentLoadedEventEnd : performance.now())) / 1000 }); } catch (x) {} }
  if (document.readyState === "complete") carga(); else window.addEventListener("load", carga);
  var saiu = false;
  function onLeave() { if (saiu) return; saiu = true; diag("Saiu", { step: tela(), value: Math.round((Date.now() - t0) / 1000) }); }
  window.addEventListener("pagehide", onLeave);
  document.addEventListener("visibilitychange", function () { if (document.visibilityState === "hidden") onLeave(); });
})();
