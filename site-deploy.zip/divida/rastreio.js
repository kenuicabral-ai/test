/*
 * Rastreamento do funil Dívida Clara (quiz e VSL).
 * - Cria uma sessão anônima que acompanha a pessoa do quiz até a compra.
 * - Guarda as UTMs do anúncio.
 * - Mostra o aviso de cookies; o pixel do Meta só liga com consentimento.
 * - Cada evento vai para o pixel e para o seu servidor (api/track.php) com o
 *   MESMO ID, para a Meta descartar o duplicado.
 * Configure em cada página: window.RASTREIO_CONFIG = { page, pixelId, trackUrl }
 */
(function () {
  var R = window.RASTREIO_CONFIG || {};
  var UTM_KEYS = ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"];
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  function rid() {
    var a = new Uint8Array(12);
    (window.crypto || window.msCrypto).getRandomValues(a);
    return Array.prototype.map.call(a, function (b) { return ("0" + b.toString(16)).slice(-2); }).join("");
  }
  function cookie(name) { var m = document.cookie.match(new RegExp("(?:^|; )" + name + "=([^;]*)")); return m ? decodeURIComponent(m[1]) : null; }

  /* Sessão anônima */
  var sid = store("dc_sid");
  if (!sid) { sid = "s" + rid(); store("dc_sid", sid); }

  /* UTMs: as da URL atual têm prioridade; senão, as guardadas da visita anterior */
  var params = new URLSearchParams(location.search), utm = {};
  var saved = {}; try { saved = JSON.parse(store("dc_utm") || "{}"); } catch (e) {}
  var hasNew = UTM_KEYS.some(function (k) { return params.get(k); });
  UTM_KEYS.forEach(function (k) { var v = hasNew ? params.get(k) : saved[k]; if (v) utm[k] = v; });
  if (hasNew) store("dc_utm", JSON.stringify(utm));

  /* fbclid → cookie _fbc (melhora a correspondência na Meta) */
  var fbclid = params.get("fbclid");
  if (fbclid && !cookie("_fbc")) {
    document.cookie = "_fbc=fb.1." + Date.now() + "." + fbclid + "; path=/; max-age=7776000; SameSite=Lax";
  }

  /* Consentimento e pixel */
  var consent = store("dc_consent") === "yes", pixelOn = false, pageViewId = "pv_" + rid();
  function loadPixel() {
    if (!R.pixelId || pixelOn) return; pixelOn = true;
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
    fbq("init", R.pixelId);
    fbq("track", "PageView", {}, { eventID: pageViewId });
  }

  /* Envia para o servidor */
  function send(body) {
    if (!R.trackUrl) return;
    var json = JSON.stringify(body);
    try {
      if (navigator.sendBeacon && navigator.sendBeacon(R.trackUrl, new Blob([json], { type: "text/plain" }))) return;
    } catch (e) {}
    try { fetch(R.trackUrl, { method: "POST", body: json, keepalive: true, headers: { "Content-Type": "text/plain" } }); } catch (e) {}
  }

  /*
   * dcTrack("Lead", { custom, data, step, level, value, lead, id, perfil, quiz })
   * custom: true para eventos personalizados (QuizStart, QuizStep, QuizComplete, QuizSkipLead, VideoProgress)
   * perfil: "a" | "b" | "c" (resultado do quiz). Fica guardado e vai junto em todos os eventos seguintes.
   * quiz: respostas do quiz { tipo_divida, tempo_atraso, cobrador, historico, sobra_mes }
   */
  function dcTrack(ev, o) {
    o = o || {};
    var id = o.id || (ev.toLowerCase() + "_" + rid());
    if (pixelOn && window.fbq && ev !== "PageView") {
      var data = o.data || {};
      if (o.custom) fbq("trackCustom", ev, data, { eventID: id }); else fbq("track", ev, data, { eventID: id });
    }
    var p = o.perfil || params.get("p") || store("dc_perfil");
    if (p && /^[abc]$/.test(p)) store("dc_perfil", p); else p = undefined;
    send({
      ev: ev, id: id, sid: sid, page: R.page, url: location.href.split("#")[0],
      consent: consent, utm: utm, step: o.step, level: o.level, value: o.value, lead: o.lead,
      perfil: p, quiz: o.quiz,
      fbp: cookie("_fbp"), fbc: cookie("_fbc")
    });
    return id;
  }

  window.dcTrack = dcTrack;
  window.dcSession = function () { return sid; };
  window.dcUtm = function () { return utm; };

  /* Aviso de cookies (elemento #consent da página) */
  function initBanner() {
    var banner = document.getElementById("consent");
    var choice = store("dc_consent");
    if (choice === "yes") loadPixel();
    else if (choice !== "no" && R.pixelId && banner) banner.classList.add("show");
    if (banner) banner.addEventListener("click", function (e) {
      var b = e.target.closest("[data-consent]"); if (!b) return;
      store("dc_consent", b.dataset.consent); banner.classList.remove("show");
      if (b.dataset.consent === "yes") { consent = true; loadPixel(); }
    });
    // PageView no servidor com o mesmo ID do pixel
    dcTrack("PageView", { id: pageViewId });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initBanner); else initBanner();
})();
