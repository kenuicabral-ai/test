<?php
/*
 * =====================================================================
 * CONFIGURAÇÃO DO RASTREAMENTO — Dívida Clara
 * Preencha os campos abaixo pelo Gerenciador de Arquivos da HostGator.
 * Este arquivo nunca deve ser enviado para ninguém nem colado em chat.
 * =====================================================================
 */
return [

    // Banco de dados MySQL (crie no cPanel > Bancos de dados MySQL)
    'db' => [
        'host' => 'localhost',
        'name' => '',   // ex.: seuusuario_funil
        'user' => '',   // ex.: seuusuario_funil
        'pass' => '',
    ],

    // Meta: ID do pixel e token da API de Conversões (Gerenciador de Eventos > Configurações)
    'pixel_id'    => '',
    'capi_token'  => '',
    // Versão da API Graph. Confira a versão atual em developers.facebook.com/docs/graph-api/changelog
    'graph_version' => 'v21.0',
    // Código de teste do Gerenciador de Eventos (aba "Testar eventos"). Deixe vazio em produção.
    'test_event_code' => '',

    // Senha para abrir o painel do funil (painel.php). Use uma senha forte.
    'painel_senha' => '',

    // Hotmart: o "hottok" da sua conta (Ferramentas > Webhook). Garante que só a Hotmart envia vendas.
    'hotmart_hottok' => '',
    // Deixe false se a integração nativa da Hotmart já envia o Purchase para a Meta (evita duplicar).
    'webhook_envia_purchase_meta' => false,

    // Endereço do seu site, para aceitar eventos só das suas páginas. Ex.: https://seusite.com.br
    'site_origin' => '',
];
