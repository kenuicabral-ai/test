<?php
/*
 * Webhook da Hotmart: registra vendas, reembolsos e cancelamentos no painel.
 * Cadastre na Hotmart (Ferramentas > Webhook) a URL:
 *   https://seusite.com.br/divida/api/webhook.php
 * e marque os eventos de compra (aprovada, completa, reembolsada, cancelada, chargeback).
 */
require __DIR__ . '/lib.php';

$raw = file_get_contents('php://input');
$in = json_decode($raw, true);
if (!is_array($in)) $in = $_POST; // formato antigo (formulário)

// 1) Confere o hottok: garante que quem enviou foi a Hotmart
$hottok = $_SERVER['HTTP_X_HOTMART_HOTTOK'] ?? ($in['hottok'] ?? '');
$expected = (string)cfg('hotmart_hottok');
if ($expected === '' || !hash_equals($expected, (string)$hottok)) json_out(['ok' => false, 'erro' => 'hottok'], 401);

// 2) Lê os campos (formato atual da Hotmart, com alternativas para o antigo)
$d = $in['data'] ?? $in;
$pick = function (array $paths) use ($d) {
    foreach ($paths as $p) {
        $cur = $d;
        foreach (explode('.', $p) as $k) { if (!is_array($cur) || !array_key_exists($k, $cur)) { $cur = null; break; } $cur = $cur[$k]; }
        if ($cur !== null && $cur !== '') return $cur;
    }
    return null;
};
$evento    = (string)($in['event'] ?? $pick(['status']) ?? 'DESCONHECIDO');
$transacao = (string)($pick(['purchase.transaction', 'transaction']) ?? '');
$status    = (string)($pick(['purchase.status', 'status']) ?? '');
$produto   = (string)($pick(['product.name', 'prod_name']) ?? '');
$oferta    = (string)($pick(['purchase.offer.code', 'off']) ?? '');
$valor     = $pick(['purchase.price.value', 'purchase.full_price.value', 'price']);
$sessao    = $pick(['purchase.origin.sck', 'sck']);  // o ID da sessão que a página manda no link do checkout
$src       = $pick(['purchase.origin.src', 'src']);
if ($transacao === '') json_out(['ok' => false, 'erro' => 'sem_transacao'], 400);

// 3) Grava ou atualiza a venda
$now = date('Y-m-d H:i:s');
$exists = db()->prepare('SELECT id FROM vendas WHERE transacao = ?');
$exists->execute([$transacao]);
if ($exists->fetch()) {
    db()->prepare('UPDATE vendas SET atualizado_em=?, evento=?, status=?, valor=COALESCE(?, valor) WHERE transacao=?')
        ->execute([$now, $evento, $status, $valor !== null ? (float)$valor : null, $transacao]);
} else {
    db()->prepare('INSERT INTO vendas (atualizado_em, transacao, evento, status, produto, oferta, valor, sessao, src) VALUES (?,?,?,?,?,?,?,?,?)')
        ->execute([$now, $transacao, $evento, $status, mb_substr($produto, 0, 150), mb_substr($oferta, 0, 60), $valor !== null ? (float)$valor : null, $sessao ? mb_substr((string)$sessao, 0, 60) : null, $src ? mb_substr((string)$src, 0, 150) : null]);
}

// 4) Opcional: envia o Purchase pela sua API (só se a integração nativa da Hotmart estiver desligada)
if (cfg('webhook_envia_purchase_meta') && in_array($evento, ['PURCHASE_APPROVED', 'PURCHASE_COMPLETE'], true) && $valor !== null) {
    $email = $pick(['buyer.email', 'email']);
    $phone = $pick(['buyer.checkout_phone', 'buyer.phone', 'phone_number']);
    send_capi([
        'event_name' => 'Purchase',
        'event_time' => time(),
        'event_id' => 'purchase_' . $transacao,
        'action_source' => 'website',
        'user_data' => array_filter([
            'em' => $email ? [meta_hash($email)] : null,
            'ph' => $phone ? [meta_phone($phone)] : null,
            'external_id' => $sessao ? [hash('sha256', (string)$sessao)] : null,
        ]),
        'custom_data' => ['value' => (float)$valor, 'currency' => 'BRL', 'content_name' => $produto],
    ]);
}

json_out(['ok' => true]);
