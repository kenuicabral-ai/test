<?php
/*
 * Cria as tabelas do banco. Abra uma vez no navegador:
 *   https://seusite.com.br/divida/api/instalar.php?senha=SUA_SENHA_DO_PAINEL
 * Depois que aparecer "Instalação concluída", APAGUE este arquivo da hospedagem.
 */
require_once __DIR__ . '/lib.php';
if (!headers_sent()) header('Content-Type: text/plain; charset=utf-8');

$senha = cfg('painel_senha');
if (!$senha || !hash_equals($senha, (string)($_GET['senha'] ?? ''))) {
    http_response_code(403);
    exit("Acesso negado. Preencha 'painel_senha' no config.php e abra com ?senha=...\n");
}

$isSqlite = strpos((string)(cfg('db')['dsn'] ?? ''), 'sqlite') === 0;
$auto = $isSqlite ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : 'BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY';
$tail = $isSqlite ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4';

$sql = [
"CREATE TABLE IF NOT EXISTS eventos (
  id $auto,
  criado_em DATETIME NOT NULL,
  event_id VARCHAR(64) NOT NULL UNIQUE,
  evento VARCHAR(40) NOT NULL,
  pagina VARCHAR(20) NOT NULL,
  etapa VARCHAR(20) NULL,
  sessao VARCHAR(40) NOT NULL,
  utm_source VARCHAR(100) NULL, utm_medium VARCHAR(100) NULL, utm_campaign VARCHAR(150) NULL,
  utm_content VARCHAR(150) NULL, utm_term VARCHAR(150) NULL,
  nivel_quiz TINYINT NULL,
  perfil CHAR(1) NULL,
  respostas VARCHAR(255) NULL,
  valor DECIMAL(10,2) NULL,
  consentiu TINYINT NOT NULL DEFAULT 0,
  meta_status VARCHAR(20) NULL
)$tail",
"CREATE TABLE IF NOT EXISTS leads (
  id $auto,
  criado_em DATETIME NOT NULL,
  sessao VARCHAR(40) NOT NULL,
  nome VARCHAR(80) NOT NULL DEFAULT '',
  whatsapp VARCHAR(20) NOT NULL,
  nivel_quiz TINYINT NULL,
  perfil CHAR(1) NULL,
  respostas VARCHAR(255) NULL,
  utm_source VARCHAR(100) NULL, utm_campaign VARCHAR(150) NULL, utm_content VARCHAR(150) NULL
)$tail",
"CREATE TABLE IF NOT EXISTS vendas (
  id $auto,
  atualizado_em DATETIME NOT NULL,
  transacao VARCHAR(60) NOT NULL UNIQUE,
  evento VARCHAR(40) NOT NULL,
  status VARCHAR(40) NULL,
  produto VARCHAR(150) NULL,
  oferta VARCHAR(60) NULL,
  valor DECIMAL(10,2) NULL,
  sessao VARCHAR(60) NULL,
  src VARCHAR(150) NULL
)$tail",
];
foreach ($sql as $q) db()->exec($q);
/* Atualização de quem já tinha instalado a versão anterior (ignora se a coluna já existe) */
foreach (["ALTER TABLE eventos ADD COLUMN perfil CHAR(1) NULL", "ALTER TABLE eventos ADD COLUMN respostas VARCHAR(255) NULL",
          "ALTER TABLE leads ADD COLUMN perfil CHAR(1) NULL", "ALTER TABLE leads ADD COLUMN respostas VARCHAR(255) NULL"] as $q) {
    try { db()->exec($q); } catch (Exception $e) { /* já existe */ }
}
if (!$isSqlite) {
    try { db()->exec("ALTER TABLE leads MODIFY nome VARCHAR(80) NOT NULL DEFAULT ''"); } catch (Exception $e) {}
    foreach (["CREATE INDEX ix_ev_sessao ON eventos (sessao)", "CREATE INDEX ix_ev_evento ON eventos (evento, criado_em)", "CREATE INDEX ix_ve_sessao ON vendas (sessao)", "CREATE INDEX ix_ev_perfil ON eventos (perfil)"] as $q) {
        try { db()->exec($q); } catch (Exception $e) { /* índice já existe */ }
    }
}
$apagado = @unlink(__FILE__);
echo $apagado ? "Instalação concluída. O instalador foi apagado automaticamente.\n" : "Instalação concluída. Agora APAGUE o arquivo instalar.php da hospedagem.\n";
