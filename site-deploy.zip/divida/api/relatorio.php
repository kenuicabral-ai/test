<?php
/*
 * Relatório do funil em JSON, só com números agregados (sem nome, WhatsApp, e-mail ou IP).
 * Usado pela análise diária. Acesso: relatorio.php?t=TOKEN[&de=AAAA-MM-DD&ate=AAAA-MM-DD]
 * O token fica em 'relatorio_token' no config.php. Sem token configurado, o relatório fica desligado.
 */
require __DIR__ . '/lib.php';
header('Cache-Control: no-store');
/* HTML com o JSON dentro de <pre> (leitores automáticos aceitam melhor); ?formato=json devolve JSON puro */
function rel_out($data, $code = 200) {
    http_response_code($code);
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if (($_GET['formato'] ?? '') === 'json') { header('Content-Type: application/json; charset=utf-8'); echo $json; exit; }
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="robots" content="noindex"><title>Relatório do funil</title></head><body><pre>'
       . htmlspecialchars($json, ENT_NOQUOTES, 'UTF-8') . '</pre></body></html>';
    exit;
}

$token = (string)cfg('relatorio_token');
if (strlen($token) < 32 || !hash_equals($token, (string)($_GET['t'] ?? ''))) {
    sleep(1);
    rel_out(['ok' => false, 'erro' => 'acesso negado'], 403);
}

$hoje = date('Y-m-d');
$de  = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['de'] ?? '')  ? $_GET['de']  : date('Y-m-d', strtotime('-6 days'));
$ate = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['ate'] ?? '') ? $_GET['ate'] : $hoje;
$ini = $de . ' 00:00:00'; $fim = $ate . ' 23:59:59';
$OK = "('PURCHASE_APPROVED','PURCHASE_COMPLETE')";
$DEV = "('PURCHASE_REFUNDED','PURCHASE_CHARGEBACK','PURCHASE_CANCELED','PURCHASE_PROTEST')";

function q($sql, $args = []) { $st = db()->prepare($sql); $st->execute($args); return $st; }
function n_sess($ini, $fim, $ev, $page = null, $step = null) {
    $sql = 'SELECT COUNT(DISTINCT sessao) n FROM eventos WHERE criado_em BETWEEN ? AND ? AND evento = ?'; $a = [$ini, $fim, $ev];
    if ($page !== null) { $sql .= ' AND pagina = ?'; $a[] = $page; }
    if ($step !== null) { $sql .= ' AND etapa = ?'; $a[] = (string)$step; }
    return (int)q($sql, $a)->fetch()['n'];
}
function etapas($ini, $fim) {
    return [
        'quiz_visitas'      => n_sess($ini, $fim, 'PageView', 'quiz'),
        'quiz_comecou'      => n_sess($ini, $fim, 'QuizStart'),
        'quiz_p1'           => n_sess($ini, $fim, 'QuizStep', null, 1),
        'quiz_p2'           => n_sess($ini, $fim, 'QuizStep', null, 2),
        'quiz_p3'           => n_sess($ini, $fim, 'QuizStep', null, 3),
        'quiz_p4'           => n_sess($ini, $fim, 'QuizStep', null, 4),
        'quiz_p5'           => n_sess($ini, $fim, 'QuizStep', null, 5),
        'quiz_terminou'     => n_sess($ini, $fim, 'QuizComplete'),
        'deixou_whatsapp'   => n_sess($ini, $fim, 'Lead'),
        'pulou_whatsapp'    => n_sess($ini, $fim, 'QuizSkipLead'),
        'copiou_mensagem'   => n_sess($ini, $fim, 'FreeMessageCopy'),
        'vsl_visitas'       => n_sess($ini, $fim, 'PageView', 'vsl'),
        'video_25'          => n_sess($ini, $fim, 'VideoProgress', null, 25),
        'video_50'          => n_sess($ini, $fim, 'VideoProgress', null, 50),
        'video_75'          => n_sess($ini, $fim, 'VideoProgress', null, 75),
        'viu_oferta'        => n_sess($ini, $fim, 'ViewContent'),
        'clicou_comprar'    => n_sess($ini, $fim, 'InitiateCheckout'),
    ];
}
/* Classifica a venda pelo nome do produto da Hotmart */
function tipo_produto($nome) {
    $n = mb_strtolower((string)$nome);
    if (strpos($n, 'família') !== false || strpos($n, 'familia') !== false) return 'upsell_plano_familia';
    if (strpos($n, '+1 plano') !== false) return 'downsell_mais1';
    if (strpos($n, 'roteiro') !== false || strpos($n, 'credor') !== false || strpos($n, 'cobradora') !== false) return 'bump_roteiros';
    if (strpos($n, 'dívida vendida') !== false || strpos($n, 'divida vendida') !== false || strpos($n, 'dívida clara') !== false) return 'principal';
    return 'outro';
}
function vendas($ini, $fim) {
    global $OK, $DEV;
    $r = ['aprovadas' => [], 'devolvidas' => [], 'outros_status' => []];
    foreach (q("SELECT produto, evento, COUNT(*) n, COALESCE(SUM(valor),0) v FROM vendas WHERE atualizado_em BETWEEN ? AND ? GROUP BY produto, evento", [$ini, $fim]) as $x) {
        $t = tipo_produto($x['produto']);
        $grupo = in_array($x['evento'], ['PURCHASE_APPROVED', 'PURCHASE_COMPLETE'], true) ? 'aprovadas'
               : (in_array($x['evento'], ['PURCHASE_REFUNDED', 'PURCHASE_CHARGEBACK', 'PURCHASE_CANCELED', 'PURCHASE_PROTEST'], true) ? 'devolvidas' : 'outros_status');
        if ($grupo === 'outros_status') { $k = $t . ':' . $x['evento']; $r[$grupo][$k] = ($r[$grupo][$k] ?? 0) + (int)$x['n']; continue; }
        $r[$grupo][$t]['qtd'] = ($r[$grupo][$t]['qtd'] ?? 0) + (int)$x['n'];
        $r[$grupo][$t]['valor'] = round(($r[$grupo][$t]['valor'] ?? 0) + (float)$x['v'], 2);
    }
    $r['faturamento_aprovado'] = round(array_sum(array_column($r['aprovadas'], 'valor')), 2);
    return $r;
}

/* Período pedido */
$out = ['ok' => true, 'gerado_em' => date('c'), 'fuso' => 'America/Sao_Paulo', 'periodo' => ['de' => $de, 'ate' => $ate]];
$out['etapas'] = etapas($ini, $fim);
$out['vendas'] = vendas($ini, $fim);

/* Dia a dia */
$dias = [];
for ($d = strtotime($de); $d <= strtotime($ate); $d += 86400) {
    $dia = date('Y-m-d', $d); $a = $dia . ' 00:00:00'; $b = $dia . ' 23:59:59';
    $v = vendas($a, $b);
    $dias[] = ['dia' => $dia, 'quiz_visitas' => n_sess($a, $b, 'PageView', 'quiz'), 'quiz_terminou' => n_sess($a, $b, 'QuizComplete'),
               'vsl_visitas' => n_sess($a, $b, 'PageView', 'vsl'), 'viu_oferta' => n_sess($a, $b, 'ViewContent'),
               'clicou_comprar' => n_sess($a, $b, 'InitiateCheckout'), 'principal_aprovadas' => $v['aprovadas']['principal']['qtd'] ?? 0,
               'faturamento' => $v['faturamento_aprovado']];
}
$out['dia_a_dia'] = $dias;

/* Por campanha e anúncio (vendas ligadas pela sessão que vai no sck) */
$ads = [];
foreach (q("SELECT COALESCE(utm_campaign,'(sem campanha)') c, COALESCE(utm_content,'(sem anúncio)') a,
    COUNT(DISTINCT CASE WHEN evento='PageView' AND pagina='quiz' THEN sessao END) quiz_visitas,
    COUNT(DISTINCT CASE WHEN evento='QuizComplete' THEN sessao END) quiz_terminou,
    COUNT(DISTINCT CASE WHEN evento='PageView' AND pagina='vsl' THEN sessao END) vsl_visitas,
    COUNT(DISTINCT CASE WHEN evento='ViewContent' THEN sessao END) viu_oferta,
    COUNT(DISTINCT CASE WHEN evento='InitiateCheckout' THEN sessao END) clicou_comprar
    FROM eventos WHERE criado_em BETWEEN ? AND ? GROUP BY c, a ORDER BY quiz_visitas DESC LIMIT 60", [$ini, $fim]) as $r) {
    $ads[$r['c'] . '|' . $r['a']] = ['campanha' => $r['c'], 'anuncio' => $r['a']] + array_map('intval', array_diff_key($r, ['c' => 1, 'a' => 1])) + ['vendas' => 0, 'faturamento' => 0];
}
foreach (q("SELECT COALESCE(e.utm_campaign,'(sem campanha)') c, COALESCE(e.utm_content,'(sem anúncio)') a, COUNT(DISTINCT v.transacao) n, COALESCE(SUM(v.valor),0) v
    FROM vendas v JOIN (SELECT DISTINCT sessao, utm_campaign, utm_content FROM eventos WHERE criado_em BETWEEN ? AND ?) e ON e.sessao = v.sessao
    WHERE v.evento IN $OK AND v.atualizado_em BETWEEN ? AND ? GROUP BY c, a", [$ini, $fim, $ini, $fim]) as $r) {
    $k = $r['c'] . '|' . $r['a'];
    if (!isset($ads[$k])) $ads[$k] = ['campanha' => $r['c'], 'anuncio' => $r['a'], 'quiz_visitas' => 0, 'quiz_terminou' => 0, 'vsl_visitas' => 0, 'viu_oferta' => 0, 'clicou_comprar' => 0, 'vendas' => 0, 'faturamento' => 0];
    $ads[$k]['vendas'] = (int)$r['n']; $ads[$k]['faturamento'] = round((float)$r['v'], 2);
}
$out['por_anuncio'] = array_values($ads);

/* Por perfil e resposta do quiz: quem terminou e o que fez depois */
$sessoes = function ($ev, $page = null) use ($ini, $fim) {
    $sql = 'SELECT DISTINCT sessao FROM eventos WHERE criado_em BETWEEN ? AND ? AND evento = ?' . ($page ? ' AND pagina = ?' : '');
    return array_flip(q($sql, $page ? [$ini, $fim, $ev, $page] : [$ini, $fim, $ev])->fetchAll(PDO::FETCH_COLUMN));
};
$sVsl = $sessoes('PageView', 'vsl'); $sOf = $sessoes('ViewContent'); $sCk = $sessoes('InitiateCheckout');
$sVenda = array_flip(q("SELECT DISTINCT sessao FROM vendas WHERE evento IN $OK AND atualizado_em BETWEEN ? AND ? AND sessao IS NOT NULL", [$ini, $fim])->fetchAll(PDO::FETCH_COLUMN));
$seg = [];
foreach (q("SELECT sessao, perfil, respostas FROM eventos WHERE criado_em BETWEEN ? AND ? AND evento = 'QuizComplete'", [$ini, $fim]) as $r) {
    $resp = json_decode((string)$r['respostas'], true) ?: [];
    $campos = ['perfil' => $r['perfil']] + array_intersect_key($resp, array_flip(['tipo_divida', 'tempo_atraso', 'cobrador', 'historico', 'sobra_mes']));
    foreach ($campos as $c => $val) {
        if ($val === null || $val === '') continue;
        $L = $seg[$c][$val] ?? ['quiz_terminou' => 0, 'vsl' => 0, 'viu_oferta' => 0, 'clicou_comprar' => 0, 'comprou' => 0];
        $L['quiz_terminou']++;
        if (isset($sVsl[$r['sessao']])) $L['vsl']++;
        if (isset($sOf[$r['sessao']])) $L['viu_oferta']++;
        if (isset($sCk[$r['sessao']])) $L['clicou_comprar']++;
        if (isset($sVenda[$r['sessao']])) $L['comprou']++;
        $seg[$c][$val] = $L;
    }
}
$out['por_resposta_do_quiz'] = $seg;

/* Saúde do rastreamento */
$out['saude'] = [
    'eventos_recusados_pela_meta' => (int)q("SELECT COUNT(*) n FROM eventos WHERE criado_em BETWEEN ? AND ? AND meta_status IS NOT NULL AND meta_status NOT IN ('200','sem_consent')", [$ini, $fim])->fetch()['n'],
    'eventos_total' => (int)q("SELECT COUNT(*) n FROM eventos WHERE criado_em BETWEEN ? AND ?", [$ini, $fim])->fetch()['n'],
    'consentiu_cookies' => (int)q("SELECT COUNT(DISTINCT sessao) n FROM eventos WHERE criado_em BETWEEN ? AND ? AND consentiu = 1", [$ini, $fim])->fetch()['n'],
    'ultimo_evento' => q("SELECT MAX(criado_em) m FROM eventos")->fetch()['m'],
    'ultima_venda_recebida' => q("SELECT MAX(atualizado_em) m FROM vendas")->fetch()['m'],
    'vendas_sem_sessao' => (int)q("SELECT COUNT(*) n FROM vendas WHERE atualizado_em BETWEEN ? AND ? AND sessao IS NULL", [$ini, $fim])->fetch()['n'],
];

rel_out($out);
