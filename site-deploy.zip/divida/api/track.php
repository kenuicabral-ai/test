<?php
/*
 * Recebe os eventos do quiz e da VSL, salva no banco e envia para a
 * API de Conversões da Meta (menos para quem tocou em "Não quero" no aviso de cookies).
 * O mesmo event_id é usado pelo pixel no navegador, então a Meta
 * descarta o evento duplicado.
 */
require __DIR__ . '/lib.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false], 405);

// Aceita só eventos vindos do seu site
$origin = rtrim((string)cfg('site_origin'), '/');
if ($origin) {
    $from = $_SERVER['HTTP_ORIGIN'] ?? ($_SERVER['HTTP_REFERER'] ?? '');
    if (strpos($from, $origin) !== 0) json_out(['ok' => false, 'erro' => 'origem'], 403);
}

$in = json_decode(file_get_contents('php://input'), true);
if (!is_array($in)) json_out(['ok' => false, 'erro' => 'json'], 400);

$ALLOWED = ['PageView', 'QuizStart', 'QuizStep', 'QuizComplete', 'QuizSkipLead', 'FreeMessageCopy', 'Lead', 'VideoProgress', 'ViewContent', 'InitiateCheckout'];
$STANDARD = ['PageView', 'Lead', 'ViewContent', 'InitiateCheckout'];

$ev = (string)($in['ev'] ?? '');
$id = preg_replace('/[^A-Za-z0-9_.-]/', '', (string)($in['id'] ?? ''));
$sid = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($in['sid'] ?? ''));
$page = in_array($in['page'] ?? '', ['quiz', 'vsl', 'conteudo', 'advertorial'], true) ? $in['page'] : 'outra';
if (!in_array($ev, $ALLOWED, true) || strlen($id) < 8 || strlen($sid) < 8) json_out(['ok' => false, 'erro' => 'dados'], 400);

$utm = is_array($in['utm'] ?? null) ? $in['utm'] : [];
$u = function ($k) use ($utm) { $v = trim(str_replace('+', ' ', (string)($utm[$k] ?? ''))); return $v === '' ? null : mb_substr($v, 0, 150); };
$step = isset($in['step']) ? mb_substr((string)$in['step'], 0, 20) : null;
$level = isset($in['level']) ? max(1, min(3, (int)$in['level'])) : null;
$value = isset($in['value']) ? round((float)$in['value'], 2) : null;
$consent = !empty($in['consent']) ? 1 : 0;
$perfil = in_array($in['perfil'] ?? '', ['a', 'b', 'c'], true) ? $in['perfil'] : null;

// Respostas do quiz: só campos e valores conhecidos (nada de texto livre)
$QUIZ = [
    'tipo_divida'  => ['cartao', 'emprestimo', 'cheque', 'conta', 'varias'],
    'tempo_atraso' => ['menos6m', '6m_1a', '1a_2a', '2a_5a', 'mais5a', 'naosei'],
    'cobrador'     => ['banco', 'desconhecida', 'escritorio', 'ninguem', 'varios'],
    'historico'    => ['nunca', 'naofechou', 'quebrou', 'voltou', 'pagando'],
    'sobra_mes'    => ['0', 'ate100', '100_300', '300_600', 'mais600'],
];
$quiz = [];
if (is_array($in['quiz'] ?? null)) {
    foreach ($QUIZ as $k => $ok) {
        $v = (string)($in['quiz'][$k] ?? '');
        if (in_array($v, $ok, true)) $quiz[$k] = $v;
    }
}
$respostas = $quiz ? json_encode($quiz) : null;

// 1) Salva o evento (ignora repetidos pelo event_id)
try {
    $st = db()->prepare('INSERT INTO eventos (criado_em, event_id, evento, pagina, etapa, sessao, utm_source, utm_medium, utm_campaign, utm_content, utm_term, nivel_quiz, perfil, respostas, valor, consentiu)
                         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
    $st->execute([date('Y-m-d H:i:s'), $id, $ev, $page, $step, $sid, $u('utm_source'), $u('utm_medium'), $u('utm_campaign'), $u('utm_content'), $u('utm_term'), $level, $perfil, $respostas, $value, $consent]);
} catch (PDOException $e) {
    if (stripos($e->getMessage(), 'unique') !== false || stripos($e->getMessage(), 'duplicate') !== false) json_out(['ok' => true, 'repetido' => true]);
    json_out(['ok' => false, 'erro' => 'banco'], 500);
}

// 2) Lead do quiz: guarda o WhatsApp (e o nome, se vier). A pessoa marcou o consentimento no formulário.
$lead = is_array($in['lead'] ?? null) ? $in['lead'] : null;
$fn = $ph = null;
if ($ev === 'Lead' && $lead) {
    $nome = mb_substr(trim((string)($lead['nome'] ?? '')), 0, 80);
    $wa = preg_replace('/\D/', '', (string)($lead['whatsapp'] ?? ''));
    if (strlen($wa) >= 12 && strlen($wa) <= 13 && !empty($lead['optin'])) {
        db()->prepare('INSERT INTO leads (criado_em, sessao, nome, whatsapp, nivel_quiz, perfil, respostas, utm_source, utm_campaign, utm_content) VALUES (?,?,?,?,?,?,?,?,?,?)')
            ->execute([date('Y-m-d H:i:s'), $sid, $nome, $wa, $level, $perfil, $respostas, $u('utm_source'), $u('utm_campaign'), $u('utm_content')]);
        $fn = $nome !== '' ? meta_hash(strtok($nome, ' ')) : null;
        $ph = meta_phone($wa);
    }
}

// Responde já para a página não esperar o envio à Meta
$response = json_encode(['ok' => true]);
header('Content-Type: application/json');
header('Content-Length: ' . strlen($response));
echo $response;
if (function_exists('fastcgi_finish_request')) fastcgi_finish_request(); else { @ob_flush(); flush(); }

// 3) Envia para a API de Conversões, só com consentimento de cookies
if (!$consent) { db()->prepare('UPDATE eventos SET meta_status = ? WHERE event_id = ?')->execute(['sem_consent', $id]); exit; }

// fbc: cookie do navegador; se faltar, monta a partir do fbclid (formato exigido pela Meta)
$fbc = isset($in['fbc']) ? mb_substr((string)$in['fbc'], 0, 200) : null;
$fbclid = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($in['fbclid'] ?? ''));
if (!$fbc && $fbclid === '') { parse_str((string)parse_url((string)($in['url'] ?? ''), PHP_URL_QUERY), $q); $fbclid = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($q['fbclid'] ?? '')); }
if (!$fbc && $fbclid !== '') $fbc = 'fb.1.' . round(microtime(true) * 1000) . '.' . $fbclid;
$fbp = isset($in['fbp']) ? mb_substr((string)$in['fbp'], 0, 100) : null;
// Quem deixou o WhatsApp no quiz: o telefone (em hash) acompanha os eventos seguintes da mesma sessão
if (!$ph) {
    $l = db()->prepare('SELECT nome, whatsapp FROM leads WHERE sessao = ? ORDER BY id DESC LIMIT 1');
    $l->execute([$sid]);
    if ($r = $l->fetch()) { $ph = meta_phone($r['whatsapp']); $fn = $r['nome'] !== '' ? meta_hash(strtok($r['nome'], ' ')) : null; }
}
// Guarda os identificadores da sessão para a compra (que chega depois pelo webhook da Hotmart)
try {
    $up = db()->prepare('UPDATE sessoes SET atualizado_em = ?, fbc = COALESCE(?, fbc), fbp = COALESCE(?, fbp), ip = ?, ua = ? WHERE sessao = ?');
    $up->execute([date('Y-m-d H:i:s'), $fbc, $fbp, client_ip(), mb_substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 400), $sid]);
    if (!$up->rowCount()) db()->prepare('INSERT INTO sessoes (sessao, atualizado_em, fbc, fbp, ip, ua) VALUES (?,?,?,?,?,?)')
        ->execute([$sid, date('Y-m-d H:i:s'), $fbc, $fbp, client_ip(), mb_substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 400)]);
} catch (Exception $e) { /* tabela ainda não criada */ }

$user = array_filter([
    'client_ip_address' => client_ip(),
    'client_user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
    'fbp' => $fbp,
    'fbc' => $fbc,
    'external_id' => [hash('sha256', $sid)],
    'fn' => $fn ? [$fn] : null,
    'ph' => $ph ? [$ph] : null,
    'country' => [hash('sha256', 'br')],
]);
$custom = array_filter([
    'value' => $value,
    'currency' => $value !== null ? 'BRL' : null,
    'content_name' => $page === 'quiz' ? 'quiz_divida_vendida' : ($page === 'vsl' ? 'vsl_divida_vendida' : $page . '_divida_clara'),
    'etapa' => $step,
    // Perfil e respostas do quiz NÃO vão para a Meta: descrevem a situação financeira
    // da pessoa, e os termos da Meta proíbem enviar esse tipo de dado. Ficam só no seu banco.
], function ($v) { return $v !== null; });

$event = [
    'event_name' => $ev,
    'event_time' => time(),
    'event_id' => $id,
    'action_source' => 'website',
    'event_source_url' => mb_substr((string)($in['url'] ?? ''), 0, 500),
    'user_data' => $user,
];
if ($custom) $event['custom_data'] = $custom;

$r = send_capi($event);
db()->prepare('UPDATE eventos SET meta_status = ? WHERE event_id = ?')->execute([$r['status'], $id]);
