<?php
/*
 * Configuração única do servidor. Abre as credenciais criptografadas
 * (segredos.enc) com a chave recebida em ?k=, grava o config.php,
 * cria as tabelas do banco e apaga a si mesmo e o arquivo criptografado.
 */
header('Content-Type: text/plain; charset=utf-8');
$dir = __DIR__;
$enc = $dir . '/segredos.enc';
if (!is_file($enc)) { http_response_code(410); exit("Nada a fazer: já configurado.\n"); }
$k = (string)($_GET['k'] ?? '');
if (!preg_match('/^[0-9a-f]{64}$/', $k)) { http_response_code(403); exit("Chave ausente.\n"); }
$box = json_decode((string)file_get_contents($enc), true);
$plain = openssl_decrypt(base64_decode($box['ct'] ?? ''), 'aes-256-gcm', hex2bin($k), OPENSSL_RAW_DATA, base64_decode($box['iv'] ?? ''), base64_decode($box['tag'] ?? ''));
if ($plain === false || strpos($plain, '<?php') !== 0) { http_response_code(403); exit("Chave inválida.\n"); }
$tmp = $dir . '/config.php.tmp';
if (file_put_contents($tmp, $plain) === false || !rename($tmp, $dir . '/config.php')) { http_response_code(500); exit("Não consegui gravar o config.php.\n"); }
@chmod($dir . '/config.php', 0640);
@unlink($enc);
@unlink(__FILE__);
if (function_exists('opcache_reset')) @opcache_reset();
echo "config.php gravado.\n";
// Cria as tabelas (o instalar.php confere a senha do painel e se apaga no fim)
require_once $dir . '/lib.php';
$_GET['senha'] = (string)cfg('painel_senha');
require $dir . '/instalar.php';
