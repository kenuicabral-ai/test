<?php
/* Funções compartilhadas. Não acesse este arquivo diretamente. */

if (basename($_SERVER['SCRIPT_FILENAME'] ?? '') === 'lib.php') { http_response_code(404); exit; }
date_default_timezone_set('America/Sao_Paulo');

function cfg($key = null) {
    static $c = null;
    if ($c === null) $c = require __DIR__ . '/config.php';
    return $key === null ? $c : ($c[$key] ?? null);
}

function db() {
    static $pdo = null;
    if ($pdo) return $pdo;
    $d = cfg('db');
    $dsn = 'mysql:host=' . $d['host'] . ';dbname=' . $d['name'] . ';charset=utf8mb4';
    if (!empty($d['dsn'])) $dsn = $d['dsn']; // usado nos testes locais
    $pdo = new PDO($dsn, $d['user'] ?? null, $d['pass'] ?? null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    return $pdo;
}

function json_out($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function client_ip() {
    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) return trim(explode(',', $_SERVER[$k])[0]);
    }
    return '';
}

/* Hash SHA-256 no formato que a Meta exige (minúsculas, sem espaços) */
function meta_hash($v) {
    $v = strtolower(trim((string)$v));
    return $v === '' ? null : hash('sha256', $v);
}
function meta_phone($v) {
    $d = preg_replace('/\D/', '', (string)$v);
    if ($d === '') return null;
    if (strlen($d) <= 11) $d = '55' . $d;
    return hash('sha256', $d);
}

/* Envia um evento para a API de Conversões da Meta */
function send_capi(array $event) {
    $pixel = cfg('pixel_id'); $token = cfg('capi_token');
    if (!$pixel || !$token) return ['ok' => false, 'status' => 'sem_config'];
    $payload = ['data' => [$event]];
    if (cfg('test_event_code')) $payload['test_event_code'] = cfg('test_event_code');
    $url = 'https://graph.facebook.com/' . cfg('graph_version') . '/' . rawurlencode($pixel) . '/events?access_token=' . rawurlencode($token);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 8,
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    if ($err) return ['ok' => false, 'status' => 'erro_rede'];
    return ['ok' => $code >= 200 && $code < 300, 'status' => (string)$code, 'body' => substr((string)$body, 0, 500)];
}
