<?php
/*
 * Painel do funil. Abra: https://seusite.com.br/divida/api/painel.php
 * Entre com a 'painel_senha' do config.php.
 */
require __DIR__ . '/lib.php';
session_start();

$senha = (string)cfg('painel_senha');
if (isset($_GET['sair'])) { $_SESSION = []; session_destroy(); header('Location: painel.php'); exit; }
if ($senha === '') { http_response_code(403); exit('Defina painel_senha no config.php.'); }
/* Proteção contra tentativas repetidas: 5 erros bloqueiam o IP por 15 minutos */
$lockFile = sys_get_temp_dir() . '/dc_login_' . hash('sha256', client_ip() . __DIR__);
$lock = is_file($lockFile) ? (json_decode((string)@file_get_contents($lockFile), true) ?: []) : [];
$blocked = !empty($lock['n']) && $lock['n'] >= 5 && (time() - ($lock['t'] ?? 0)) < 900;
if (isset($_POST['senha'])) {
    if ($blocked) {
        $erro = 'Muitas tentativas. Aguarde 15 minutos.';
    } elseif (hash_equals($senha, (string)$_POST['senha'])) {
        @unlink($lockFile);
        session_regenerate_id(true); $_SESSION['ok'] = 1; header('Location: painel.php'); exit;
    } else {
        $n = ((time() - ($lock['t'] ?? 0)) < 900 ? ($lock['n'] ?? 0) : 0) + 1;
        @file_put_contents($lockFile, json_encode(['n' => $n, 't' => time()]));
        sleep(1);
        $erro = 'Senha incorreta.';
    }
}
$h = function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); };

if (empty($_SESSION['ok'])) { ?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Painel do funil</title>
<style>body{margin:0;font:18px/1.5 system-ui,sans-serif;background:#F2F5F7;color:#142B42;display:grid;place-items:center;min-height:100vh}form{background:#fff;border:1px solid #C9D3DC;border-radius:14px;padding:1.5rem;width:min(92vw,22rem)}h1{font-size:1.3rem;margin:0 0 1rem}input{width:100%;font:inherit;padding:.7rem;border:2px solid #C9D3DC;border-radius:8px;box-sizing:border-box}button{margin-top:.8rem;width:100%;font:inherit;font-weight:700;padding:.75rem;border:0;border-radius:10px;background:#1E7A4C;color:#fff}.e{color:#C2362B;margin:.5rem 0 0}</style></head>
<body><form method="post"><h1>Painel do funil</h1><label for="s">Senha</label><input id="s" type="password" name="senha" autofocus required><?php if (!empty($erro)) echo '<p class="e">' . $h($erro) . '</p>'; ?><button>Entrar</button></form></body></html>
<?php exit; }

/* ---------- Filtros ---------- */
$de  = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['de'] ?? '')  ? $_GET['de']  : date('Y-m-d', strtotime('-6 days'));
$ate = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['ate'] ?? '') ? $_GET['ate'] : date('Y-m-d');
$camp = trim((string)($_GET['campanha'] ?? ''));
$ini = $de . ' 00:00:00'; $fim = $ate . ' 23:59:59';

/* Exportar leads em CSV (para o WhatsApp) */
if (isset($_GET['csv'])) {
    $st = db()->prepare('SELECT criado_em, nome, whatsapp, perfil, respostas, utm_source, utm_campaign, utm_content FROM leads WHERE criado_em BETWEEN ? AND ? ORDER BY criado_em DESC');
    $st->execute([$ini, $fim]);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="leads_' . $de . '_a_' . $ate . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    $campos = ['tipo_divida', 'tempo_atraso', 'cobrador', 'historico', 'sobra_mes'];
    $nomePerfil = ['a' => 'A sinal forte', 'b' => 'B sinal provável', 'c' => 'C ainda no banco'];
    fputcsv($out, array_merge(['data', 'nome', 'whatsapp', 'perfil'], $campos, ['origem', 'campanha', 'anuncio']), ';');
    foreach ($st as $r) {
        $resp = json_decode((string)$r['respostas'], true) ?: [];
        $linha = [$r['criado_em'], $r['nome'], $r['whatsapp'], $nomePerfil[$r['perfil']] ?? ''];
        foreach ($campos as $c) $linha[] = $resp[$c] ?? '';
        fputcsv($out, array_merge($linha, [$r['utm_source'], $r['utm_campaign'], $r['utm_content']]), ';');
    }
    exit;
}

$campWhere = $camp !== '' ? ' AND utm_campaign = ?' : '';
$baseArgs = $camp !== '' ? [$ini, $fim, $camp] : [$ini, $fim];

function count_step($ev, $page = null, $step = null) {
    global $campWhere, $baseArgs;
    $q = 'SELECT COUNT(DISTINCT sessao) n FROM eventos WHERE criado_em BETWEEN ? AND ?' . $campWhere . ' AND evento = ?';
    $a = array_merge($baseArgs, [$ev]);
    if ($page) { $q .= ' AND pagina = ?'; $a[] = $page; }
    if ($step !== null) { $q .= ' AND etapa = ?'; $a[] = (string)$step; }
    $st = db()->prepare($q); $st->execute($a);
    return (int)$st->fetch()['n'];
}

/* Vendas aprovadas no período (filtradas pela campanha quando houver) */
$okEv = "('PURCHASE_APPROVED','PURCHASE_COMPLETE')";
if ($camp !== '') {
    $st = db()->prepare("SELECT COUNT(*) n, COALESCE(SUM(valor),0) v FROM vendas WHERE evento IN $okEv AND atualizado_em BETWEEN ? AND ? AND sessao IN (SELECT DISTINCT sessao FROM eventos WHERE utm_campaign = ?)");
    $st->execute([$ini, $fim, $camp]);
} else {
    $st = db()->prepare("SELECT COUNT(*) n, COALESCE(SUM(valor),0) v FROM vendas WHERE evento IN $okEv AND atualizado_em BETWEEN ? AND ?");
    $st->execute([$ini, $fim]);
}
$vend = $st->fetch();
$st = db()->prepare("SELECT COUNT(*) n FROM vendas WHERE evento IN ('PURCHASE_REFUNDED','PURCHASE_CHARGEBACK','PURCHASE_CANCELED') AND atualizado_em BETWEEN ? AND ?");
$st->execute([$ini, $fim]);
$reemb = (int)$st->fetch()['n'];

$steps = [
    ['Entrou no quiz',            count_step('PageView', 'quiz')],
    ['Começou o quiz',            count_step('QuizStart')],
    ['Respondeu a pergunta 1',    count_step('QuizStep', null, 1)],
    ['Respondeu a pergunta 3',    count_step('QuizStep', null, 3)],
    ['Respondeu a pergunta 5',    count_step('QuizStep', null, 5)],
    ['Terminou o quiz',           count_step('QuizComplete')],
    ['Deixou o WhatsApp (opcional)', count_step('Lead'), 'opcional'],
    ['Pulou o WhatsApp (opcional)',  count_step('QuizSkipLead'), 'opcional'],
    ['Copiou a mensagem de presente (opcional)', count_step('FreeMessageCopy'), 'opcional'],
    ['Chegou na VSL',             count_step('PageView', 'vsl')],
    ['Assistiu 25% do vídeo',     count_step('VideoProgress', null, 25)],
    ['Assistiu 50% do vídeo',     count_step('VideoProgress', null, 50)],
    ['Assistiu 75% do vídeo',     count_step('VideoProgress', null, 75)],
    ['Viu a oferta',              count_step('ViewContent')],
    ['Clicou em comprar',         count_step('InitiateCheckout')],
    ['Comprou',                   (int)$vend['n']],
];
$top = max(1, max(array_column($steps, 1)));

/* Por campanha e anúncio */
$st = db()->prepare("SELECT COALESCE(utm_campaign,'(sem campanha)') c, COALESCE(utm_content,'(sem anúncio)') a,
    COUNT(DISTINCT CASE WHEN evento='PageView' THEN sessao END) visitas,
    COUNT(DISTINCT CASE WHEN evento='QuizComplete' THEN sessao END) quiz,
    COUNT(DISTINCT CASE WHEN evento='ViewContent' THEN sessao END) oferta,
    COUNT(DISTINCT CASE WHEN evento='InitiateCheckout' THEN sessao END) checkout
    FROM eventos WHERE criado_em BETWEEN ? AND ? GROUP BY c, a ORDER BY visitas DESC LIMIT 40");
$st->execute([$ini, $fim]);
$porAnuncio = $st->fetchAll();
$vs = db()->prepare("SELECT e.utm_campaign c, e.utm_content a, COUNT(DISTINCT v.transacao) n, COALESCE(SUM(v.valor),0) v
    FROM vendas v JOIN (SELECT DISTINCT sessao, utm_campaign, utm_content FROM eventos) e ON e.sessao = v.sessao
    WHERE v.evento IN $okEv AND v.atualizado_em BETWEEN ? AND ? GROUP BY e.utm_campaign, e.utm_content");
$vs->execute([$ini, $fim]);
$vendAnuncio = [];
foreach ($vs as $r) $vendAnuncio[($r['c'] ?? '(sem campanha)') . '|' . ($r['a'] ?? '(sem anúncio)')] = $r;

/* Por perfil e por resposta do quiz: quem terminou o quiz e o que fez depois */
function sessoes($ev, $page = null) {
    global $ini, $fim;
    $q = 'SELECT DISTINCT sessao FROM eventos WHERE criado_em BETWEEN ? AND ? AND evento = ?' . ($page ? ' AND pagina = ?' : '');
    $st = db()->prepare($q); $st->execute($page ? [$ini, $fim, $ev, $page] : [$ini, $fim, $ev]);
    return array_flip($st->fetchAll(PDO::FETCH_COLUMN));
}
$sLead = sessoes('Lead'); $sVsl = sessoes('PageView', 'vsl'); $sOferta = sessoes('ViewContent'); $sCheck = sessoes('InitiateCheckout');
$st = db()->prepare("SELECT sessao, COUNT(DISTINCT transacao) n, COALESCE(SUM(valor),0) v FROM vendas WHERE evento IN $okEv AND atualizado_em BETWEEN ? AND ? AND sessao IS NOT NULL GROUP BY sessao");
$st->execute([$ini, $fim]);
$sVenda = [];
foreach ($st as $r) $sVenda[$r['sessao']] = $r;
$st = db()->prepare('SELECT sessao, perfil, respostas FROM eventos WHERE criado_em BETWEEN ? AND ?' . $campWhere . " AND evento = 'QuizComplete' ORDER BY criado_em");
$st->execute($baseArgs);
$quizSess = [];
foreach ($st as $r) $quizSess[$r['sessao']] = ['perfil' => $r['perfil'], 'resp' => json_decode((string)$r['respostas'], true) ?: []];

$ROTULOS = [
    'perfil'       => ['titulo' => 'Perfil do resultado', 'v' => ['a' => 'A · Sinal forte', 'b' => 'B · Sinal provável', 'c' => 'C · Ainda no banco']],
    'tipo_divida'  => ['titulo' => 'Tipo de dívida', 'v' => ['cartao' => 'Cartão de crédito', 'emprestimo' => 'Empréstimo ou consignado', 'cheque' => 'Cheque especial', 'conta' => 'Conta ou loja', 'varias' => 'Mais de uma']],
    'tempo_atraso' => ['titulo' => 'Tempo de atraso', 'v' => ['menos6m' => 'Menos de 6 meses', '6m_1a' => '6 meses a 1 ano', '1a_2a' => '1 a 2 anos', '2a_5a' => '2 a 5 anos', 'mais5a' => 'Mais de 5 anos', 'naosei' => 'Não sabe']],
    'cobrador'     => ['titulo' => 'Quem cobra', 'v' => ['banco' => 'Banco ou loja', 'desconhecida' => 'Empresa desconhecida', 'escritorio' => 'Escritório de advocacia', 'ninguem' => 'Ninguém liga', 'varios' => 'Vários números']],
    'historico'    => ['titulo' => 'Já tentou negociar', 'v' => ['nunca' => 'Nunca tentou', 'naofechou' => 'Tentou, não fechou', 'quebrou' => 'Fechou e não pagou', 'voltou' => 'Pagou e voltou a dever', 'pagando' => 'Pagando acordo']],
    'sobra_mes'    => ['titulo' => 'Quanto sobra no mês', 'v' => ['0' => 'Nada', 'ate100' => 'Até R$ 100', '100_300' => 'R$ 100 a 300', '300_600' => 'R$ 300 a 600', 'mais600' => 'Mais de R$ 600']],
];
$segmentos = [];
foreach ($ROTULOS as $campo => $cfgR) {
    $linhas = [];
    foreach ($cfgR['v'] as $val => $rot) $linhas[$val] = ['rotulo' => $rot, 'quiz' => 0, 'lead' => 0, 'vsl' => 0, 'oferta' => 0, 'check' => 0, 'vendas' => 0, 'fat' => 0];
    foreach ($quizSess as $sess => $q) {
        $val = $campo === 'perfil' ? $q['perfil'] : ($q['resp'][$campo] ?? null);
        if ($val === null || !isset($linhas[$val])) continue;
        $L = &$linhas[$val];
        $L['quiz']++;
        if (isset($sLead[$sess])) $L['lead']++;
        if (isset($sVsl[$sess])) $L['vsl']++;
        if (isset($sOferta[$sess])) $L['oferta']++;
        if (isset($sCheck[$sess])) $L['check']++;
        if (isset($sVenda[$sess])) { $L['vendas'] += (int)$sVenda[$sess]['n']; $L['fat'] += (float)$sVenda[$sess]['v']; }
        unset($L);
    }
    $segmentos[$campo] = ['titulo' => $cfgR['titulo'], 'linhas' => $linhas];
}

$camps = db()->query("SELECT DISTINCT utm_campaign FROM eventos WHERE utm_campaign IS NOT NULL ORDER BY utm_campaign")->fetchAll(PDO::FETCH_COLUMN);
$metaErr = db()->prepare("SELECT COUNT(*) n FROM eventos WHERE criado_em BETWEEN ? AND ? AND meta_status IS NOT NULL AND meta_status NOT IN ('200','sem_consent')");
$metaErr->execute([$ini, $fim]);
$metaErr = (int)$metaErr->fetch()['n'];
$money = function ($v) { return 'R$ ' . number_format((float)$v, 2, ',', '.'); };
$pct = function ($a, $b) { return $b > 0 ? number_format($a / $b * 100, 1, ',', '') . '%' : '–'; };
?>
<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">
<title>Painel do funil</title>
<style>
:root{--paper:#F2F5F7;--card:#fff;--ink:#142B42;--soft:#46596C;--line:#C9D3DC;--go:#1E7A4C;--go-soft:#E3F2EA;--stamp:#C2362B}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.5 system-ui,sans-serif}
.wrap{max-width:60rem;margin:0 auto;padding:1rem}
header{display:flex;justify-content:space-between;align-items:center;gap:1rem;margin-bottom:1rem}
h1{font-size:1.4rem;margin:0}h2{font-size:1.15rem;margin:2rem 0 .75rem}
a{color:var(--ink)}
form.f{display:flex;flex-wrap:wrap;gap:.5rem;align-items:end;background:var(--card);border:1px solid var(--line);border-radius:12px;padding:.8rem}
form.f label{font-size:.85rem;color:var(--soft);display:grid;gap:.2rem}
form.f input,form.f select{font:inherit;padding:.45rem .55rem;border:1px solid var(--line);border-radius:8px}
form.f button{font:inherit;font-weight:700;padding:.5rem .9rem;border:0;border-radius:8px;background:var(--ink);color:#fff}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(9.5rem,1fr));gap:.6rem;margin-top:1rem}
.kpi{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:.8rem}
.kpi b{display:block;font-size:1.6rem;line-height:1.1}.kpi span{font-size:.85rem;color:var(--soft)}
.step{display:grid;grid-template-columns:minmax(9rem,14rem) 1fr auto;gap:.6rem;align-items:center;padding:.45rem 0;border-bottom:1px solid var(--line)}
.bar{height:22px;background:#E3E9EE;border-radius:6px;overflow:hidden}.bar i{display:block;height:100%;background:var(--go)}
.num{font-variant-numeric:tabular-nums;text-align:right;white-space:nowrap}.num small{display:block;color:var(--soft)}
.drop{color:var(--stamp)}
table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:12px;overflow:hidden;font-size:.92rem}
th,td{padding:.5rem .6rem;border-bottom:1px solid var(--line);text-align:right;font-variant-numeric:tabular-nums}
th:first-child,td:first-child,th:nth-child(2),td:nth-child(2){text-align:left}th{background:#E3E9EE}
.scroll{overflow-x:auto}.warn{background:#FBE9E7;border:1px solid #E8B4AE;border-radius:10px;padding:.7rem;margin-top:1rem}
.note{color:var(--soft);font-size:.88rem}
@media(max-width:560px){.step{grid-template-columns:1fr auto}.step .bar{grid-column:1/-1;order:3}}
</style></head>
<body><div class="wrap">
<header><h1>Funil Dívida Clara</h1><a href="?sair=1">Sair</a></header>

<form class="f" method="get">
  <label>De<input type="date" name="de" value="<?= $h($de) ?>"></label>
  <label>Até<input type="date" name="ate" value="<?= $h($ate) ?>"></label>
  <label>Campanha<select name="campanha"><option value="">Todas</option><?php foreach ($camps as $c) echo '<option' . ($c === $camp ? ' selected' : '') . '>' . $h($c) . '</option>'; ?></select></label>
  <button>Filtrar</button>
  <a href="?de=<?= $h($de) ?>&ate=<?= $h($ate) ?>&csv=1">Baixar leads (CSV)</a>
</form>

<div class="kpis">
  <div class="kpi"><b><?= $steps[0][1] ?></b><span>pessoas no quiz</span></div>
  <div class="kpi"><b><?= $steps[9][1] ?></b><span>chegaram na VSL</span></div>
  <div class="kpi"><b><?= (int)$vend['n'] ?></b><span>vendas aprovadas</span></div>
  <div class="kpi"><b><?= $money($vend['v']) ?></b><span>faturamento bruto</span></div>
  <div class="kpi"><b><?= $pct((int)$vend['n'], $steps[9][1]) ?></b><span>conversão da VSL</span></div>
  <div class="kpi"><b><?= $reemb ?></b><span>reembolsos e cancelamentos</span></div>
</div>
<?php if ($metaErr) echo '<p class="warn">' . $metaErr . ' eventos não foram aceitos pela Meta neste período. Confira o token e o ID do pixel no config.php.</p>'; ?>

<h2>Onde as pessoas param</h2>
<?php $prev = null; foreach ($steps as $s): $w = round($s[1] / $top * 100, 1); ?>
  <div class="step">
    <div><?= $h($s[0]) ?></div>
    <div class="bar" aria-hidden="true"><i style="width:<?= $w ?>%"></i></div>
    <div class="num"><?= $s[1] ?><small<?= ($prev !== null && $prev > 0 && $s[1] / $prev < .5) ? ' class="drop"' : '' ?>><?= $prev === null ? '' : $pct($s[1], $prev) . ' da etapa anterior' ?></small></div>
  </div>
<?php if (empty($s[2])) $prev = $s[1]; endforeach; ?>
<p class="note">Em vermelho: etapas em que menos da metade passou para a seguinte. Comece a otimizar por elas.</p>

<h2>Por perfil e por resposta do quiz</h2>
<p class="note">Conta só quem terminou o quiz no período. "Conv." é vendas sobre quem terminou o quiz. Use para responder perguntas como "cartão com mais de 2 anos converte mais?".</p>
<?php foreach ($segmentos as $campo => $seg): ?>
<h3 style="font-size:1rem;margin:1.2rem 0 .4rem"><?= $h($seg['titulo']) ?></h3>
<div class="scroll"><table>
  <tr><th>Resposta</th><th>Quiz completo</th><th>WhatsApp</th><th>Chegou na VSL</th><th>Viu oferta</th><th>Checkout</th><th>Vendas</th><th>Faturamento</th><th>Conv.</th></tr>
  <?php foreach ($seg['linhas'] as $r): if (!$r['quiz']) continue; ?>
  <tr><td><?= $h($r['rotulo']) ?></td><td><?= $r['quiz'] ?></td><td><?= $r['lead'] ?></td><td><?= $r['vsl'] ?></td><td><?= $r['oferta'] ?></td><td><?= $r['check'] ?></td><td><?= $r['vendas'] ?></td><td><?= $money($r['fat']) ?></td><td><?= $pct($r['vendas'], $r['quiz']) ?></td></tr>
  <?php endforeach; if (!array_sum(array_column($seg['linhas'], 'quiz'))) echo '<tr><td colspan="9">Ainda não há quiz completo neste período.</td></tr>'; ?>
</table></div>
<?php endforeach; ?>

<h2>Por campanha e anúncio</h2>
<div class="scroll"><table>
  <tr><th>Campanha</th><th>Anúncio</th><th>Visitas</th><th>Quiz completo</th><th>Viu oferta</th><th>Checkout</th><th>Vendas</th><th>Faturamento</th><th>Conv.</th></tr>
  <?php foreach ($porAnuncio as $r): $k = $r['c'] . '|' . $r['a']; $vn = $vendAnuncio[$k]['n'] ?? 0; $vv = $vendAnuncio[$k]['v'] ?? 0; ?>
  <tr><td><?= $h($r['c']) ?></td><td><?= $h($r['a']) ?></td><td><?= (int)$r['visitas'] ?></td><td><?= (int)$r['quiz'] ?></td><td><?= (int)$r['oferta'] ?></td><td><?= (int)$r['checkout'] ?></td><td><?= (int)$vn ?></td><td><?= $money($vv) ?></td><td><?= $pct($vn, (int)$r['visitas']) ?></td></tr>
  <?php endforeach; if (!$porAnuncio) echo '<tr><td colspan="9">Ainda não há eventos neste período.</td></tr>'; ?>
</table></div>
<p class="note">Para ver por anúncio, use nos anúncios do Meta: utm_source=fb&amp;utm_campaign={{campaign.name}}&amp;utm_content={{ad.name}}</p>
</div></body></html>
